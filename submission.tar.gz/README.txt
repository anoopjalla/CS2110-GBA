I created a game where a city is randomly generated each time. You must fly the airplane to the city.
If you successfully fly the airplane to the city within the timer, you win. 
Everytime you win, the counter increments. If you lose it decrements. 
If you fly out of bounds or to a wrong city or don't make it in time, you lose. 
You may restart whenever you want or after you win or lose. 
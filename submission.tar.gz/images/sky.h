/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 sky sky.png 
 * Time-stamp: Tuesday 04/04/2023, 20:12:39
 * 
 * Image Information
 * -----------------
 * sky.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SKY_H
#define SKY_H

extern const unsigned short sky[38400];
#define SKY_SIZE 76800
#define SKY_LENGTH 38400
#define SKY_WIDTH 240
#define SKY_HEIGHT 160

#endif


/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 airplane airplane.png 
 * Time-stamp: Tuesday 04/04/2023, 22:51:18
 * 
 * Image Information
 * -----------------
 * airplane.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef AIRPLANE_H
#define AIRPLANE_H

extern const unsigned short airplane[400];
#define AIRPLANE_SIZE 800
#define AIRPLANE_LENGTH 400
#define AIRPLANE_WIDTH 20
#define AIRPLANE_HEIGHT 20

#endif

